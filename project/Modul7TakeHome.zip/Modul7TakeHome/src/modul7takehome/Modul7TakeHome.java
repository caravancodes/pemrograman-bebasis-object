package modul7takehome;

public class Modul7TakeHome {

    public static void main(String[] args) {			
        Dosen dosen=new Dosen("Hudio Hizari", "PBO", 19);				
        dosen.simpanObject(dosen);	
        dosen.bacaObject(dosen);	
    }
    
}
