package modul7takehome;

import java.io.*;

public class Dosen implements Serializable{
    String namaDosen, mataKuliah;
    int umurDosen;
    public Dosen(String namaDosen, String mataKuliah, int umurDosen) {
        this.namaDosen = namaDosen;
        this.mataKuliah = mataKuliah;
        this.umurDosen = umurDosen;
    }											
    public void tampil(){							
        System.out.println("Nama Dosen\t: "+namaDosen);
        System.out.println("Umur Dosen\t: "+umurDosen);
        System.out.println("Nama Matkul\t: "+mataKuliah);			
    }				
    public void simpanObject(Dosen ob){				
        try{								
            FileOutputStream fos=new FileOutputStream("Dosen.txt");	
            ObjectOutputStream oos=new ObjectOutputStream(fos);	
            oos.writeObject(ob);						
            oos.flush();							
        }catch(IOException ioe){						
            System.err.println("Ada Error "+ioe);				
	  }									
    }									
    public void bacaObject(Dosen obb){				
        try{								
            FileInputStream fis =new FileInputStream("Dosen.txt");		
            ObjectInputStream ois=new ObjectInputStream(fis);		
            while((obb=(Dosen)ois.readObject())!=null){		
                obb.tampil();						
            }
        }catch(IOException ioe){						
            System.exit(1);					
        }catch(Exception e){						
            System.exit(1);							
        }									
    }
}
